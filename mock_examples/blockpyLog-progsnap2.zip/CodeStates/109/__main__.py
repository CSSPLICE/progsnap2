inp = open("story.txt") as inp:
    print(inp.read())