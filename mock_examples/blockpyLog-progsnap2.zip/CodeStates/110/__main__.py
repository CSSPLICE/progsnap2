inp = open("story.txt")
print(inp.read())
inp.close()