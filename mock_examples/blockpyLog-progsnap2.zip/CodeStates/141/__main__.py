a = 0
print(a - 0)
This sia  test .