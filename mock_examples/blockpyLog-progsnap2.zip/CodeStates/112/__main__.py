print(5)
