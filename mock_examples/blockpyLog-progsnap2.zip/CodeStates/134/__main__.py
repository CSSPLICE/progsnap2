import weather

vals = weather.get_weather()
for x in vals:
    x+0