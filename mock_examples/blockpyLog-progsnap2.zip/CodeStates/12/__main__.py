import weather
import matplotlib.pyplot as plt

reports = weather.get_weather()
temperatures = []
for report in reports:
    temperatures.append(report['Data']['Temperature']['Avg Temp'])
plt.hist(temperatures)
plt.show()