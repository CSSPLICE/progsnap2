a = 0
a = 0
b = 7

print(___)

ab
