if ___:
    pass

{}

if ___:
    pass
