import requests

print(requests.get("").text)