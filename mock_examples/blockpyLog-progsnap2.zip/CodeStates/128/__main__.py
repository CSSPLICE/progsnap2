a = 0
print(a - ___)

0
