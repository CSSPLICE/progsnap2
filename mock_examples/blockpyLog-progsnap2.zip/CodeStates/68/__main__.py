story = open('story.txt').read()
for l in open('nounlist.txt'):
    story.replace(l)