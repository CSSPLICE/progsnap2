print("Hello world.")
input("This is a test:")
print("Success!")