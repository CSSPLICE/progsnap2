a = ___
print(a)

0

0
