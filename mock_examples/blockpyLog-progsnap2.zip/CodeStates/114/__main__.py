print(3)
