story = open('story.txt').read()
for l in open('nounlist.txt'):
    story = story.replace(l, ")
print(story)