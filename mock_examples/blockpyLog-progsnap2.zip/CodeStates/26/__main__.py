for key, values in a_dictionary.items():
    pass
