story = open('story.txt').read()
nouns = open(