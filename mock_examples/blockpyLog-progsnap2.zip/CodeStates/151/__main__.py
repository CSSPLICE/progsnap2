a = 0
a = 0
b = 7

ab

print(___)
