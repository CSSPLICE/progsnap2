import weather


vals = weather.get_weather()
for x in vals:
    (x + 0)

weather.get("Avg Temp","(None)",'')
