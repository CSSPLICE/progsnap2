import weather


vals = weather.get("Avg Temp","(None)",'')
