import json
with open("data.json") as a:
    data = json.load(a)
print(data['Data'])