story = open('story.txt').read()
for l in open('nounlist.txt'):
    l = l.strip()
    story = story.replace(l, " ____")
print(story)