a=0
print(a)