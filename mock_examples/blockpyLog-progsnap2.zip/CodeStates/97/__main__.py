import json

json.loads('''{
    "Test": [1,2,3,4,5],
    "Data": "Wow!"
}''')