import requests
print(requests.get('https://pastebin.com/raw/V7tWn1R').text)