import weather


weather.get("Avg Temp","(None)",'')
