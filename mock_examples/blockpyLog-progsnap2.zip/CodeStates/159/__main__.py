import weather
import matplotlib.pyplot as plt


rainfalls = weather.get("Avg Temp","Location","Blacksburg, VA")
filtered = []
for rainfall in rainfalls:
    if rainfall > 0:
        filtered.append(rainfall)
plt.hist(filtered)
plt.show()
