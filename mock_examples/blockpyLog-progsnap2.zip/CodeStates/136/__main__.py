import weather


vals = weather.get("Avg Temp","(None)",'')
for x in vals:
    (x + 0)

weather.get_weather()
