a = 0

print(___)

a - 0
