with open("story.txt") as a:
    story = a.read()
    print(story)
for l in open('nounlist.txt'):
    l = l.strip()
    story = story.replace(l, "____")
print(story)