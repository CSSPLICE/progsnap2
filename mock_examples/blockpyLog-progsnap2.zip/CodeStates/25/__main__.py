for key, values in a_dictionary.items():
    pass

new = {}

for value in values:
    pass

new[key] = 0

new[key] = new[key] + value

return new

def sum_dictionary(a_dictionary):
    pass
    
print(sum_dictionary({
    "Module 1": [10, 5, 3, 5],
    "Module 2": [7, 3, 4, 5, 3],
    "Module 3": [10, 12, 4, 3, 2]
}))