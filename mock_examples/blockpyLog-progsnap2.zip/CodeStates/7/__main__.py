import weather

reports = weather.get_weather()
temperatures = []
for report in reports:
    temperatures.append(report['Temperature']['Avg Temp'])
plt.hist(temperatures)
plt.show()