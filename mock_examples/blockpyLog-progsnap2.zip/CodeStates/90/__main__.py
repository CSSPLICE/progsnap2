with open("story.txt") as a:
    story = a.read()
for l in open('words.txt'):
    #l = l.strip()
    story = story.replace(l, "____")
print(story)