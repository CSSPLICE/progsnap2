a = 0

b = 0
c = 0

d = 0
