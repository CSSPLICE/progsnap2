if ___:
    pass
