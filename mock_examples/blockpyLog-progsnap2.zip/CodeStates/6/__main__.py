import weather


u = weather.get_all()['test']

for assignment in []:
    print("Hello")

plt.plot([])