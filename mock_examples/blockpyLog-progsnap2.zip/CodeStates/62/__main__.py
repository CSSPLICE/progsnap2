story = open('story.txt').read()
