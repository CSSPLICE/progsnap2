if ___:
    pass

{"key": ___}
