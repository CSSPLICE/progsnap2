a = 0

print(a)

0
