import weather
import matplotlib.pyplot as plt

reports = weather.get_weather()
temperatures = []
for report in reports:
    print(report.keys())
    temperatures.append(report['Temperature']['Avg Temp'])
plt.hist(temperatures)
plt.show()