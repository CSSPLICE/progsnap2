if ___:
    pass

{}
