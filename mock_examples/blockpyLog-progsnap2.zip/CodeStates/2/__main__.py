if ___:
    if ___:
        pass
