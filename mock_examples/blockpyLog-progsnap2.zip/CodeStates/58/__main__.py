import json

d = json.loads(open('data.json').read())
