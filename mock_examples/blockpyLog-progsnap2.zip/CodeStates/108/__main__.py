inp = openopen("story.txt") as inp:
    print(inp.read())