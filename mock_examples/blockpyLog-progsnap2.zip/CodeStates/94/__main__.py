import json
with open("story.txt") as a:
    data = json.load(a)
print(data)