import requests
t = requests.get('https://pastebin.com/raw/V7tWn1Rj').text
print(t.lower())