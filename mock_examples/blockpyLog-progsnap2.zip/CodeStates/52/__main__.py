for line in open('cat.txt'):
    print(line)