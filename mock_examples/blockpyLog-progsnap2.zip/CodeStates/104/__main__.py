with open("story.txt") as inp:
    for line in inp:
        