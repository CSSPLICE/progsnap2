story = open('story.txt').read()
nouns = [l for l in open('nounlist.txt')]
