import json

print(json.loads(open('data.json').read()))