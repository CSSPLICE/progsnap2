import json
with open("story.txt") as a:
    data = json(a)
print(data)