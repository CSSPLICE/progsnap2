# Lab 5: Welcome to Python
NAMES = ["Austin Cory Bart"]

##### Part 1

## Question 1.1) 2pts

print("This submission represents a failed compilation. Bad work!