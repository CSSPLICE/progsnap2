# Lab 5: Welcome to Python
NAMES = ["Ada Bart"]

##### Part 1

## Question 1.1) 2pts

print("Hello world!")
print("Hopefully, this file gets deduplicated.")